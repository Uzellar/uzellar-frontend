import { useEffect, useState } from "react";
import { API_URL, authHeaders } from "../lib/api";
import NavAdmin from "../components/NavAdmin";
import { CORES, FONTES } from "../theme";

type TipoServico = "LIMPEZA" | "MANUTENCAO" | "PORTARIA" | "SEGURANCA";
const SERVICO_LABEL: Record<TipoServico, string> = {
  LIMPEZA: "Limpeza",
  MANUTENCAO: "Manutenção",
  PORTARIA: "Portaria",
  SEGURANCA: "Segurança",
};

interface Local {
  id: string;
  nome: string;
  descricao?: string;
  status: string;
}

interface EmailResponsavel {
  id: string;
  email: string;
}

interface TelefoneCondominio {
  id: string;
  numero: string;
}

interface Condominio {
  id: string;
  nome: string;
  endereco: string;
  qrCodeUrl?: string;
}

export default function Condominios() {
  const [condominios, setCondominios] = useState<Condominio[]>([]);
  const [condominioSelecionado, setCondominioSelecionado] = useState<string | null>(null);
  const [locais, setLocais] = useState<Local[]>([]);
  const [emails, setEmails] = useState<EmailResponsavel[]>([]);
  const [novoEmail, setNovoEmail] = useState("");
  const [salvandoEmail, setSalvandoEmail] = useState(false);
  const [telefones, setTelefones] = useState<TelefoneCondominio[]>([]);
  const [novoTelefone, setNovoTelefone] = useState("");
  const [salvandoTelefone, setSalvandoTelefone] = useState(false);
  const [erroTelefone, setErroTelefone] = useState<string | null>(null);
  const [carregando, setCarregando] = useState(true);

  // Formulário de novo condomínio
  const [mostrarFormCondominio, setMostrarFormCondominio] = useState(false);
  const [nome, setNome] = useState("");
  const [cnpj, setCnpj] = useState("");
  const [endereco, setEndereco] = useState("");
  const [servicos, setServicos] = useState<TipoServico[]>(["LIMPEZA", "MANUTENCAO", "PORTARIA", "SEGURANCA"]);
  const [emailResponsavel, setEmailResponsavel] = useState("");
  const [salvandoCondominio, setSalvandoCondominio] = useState(false);

  // Formulário de novo local (ambiente)
  const [mostrarFormLocal, setMostrarFormLocal] = useState(false);
  const [nomeLocal, setNomeLocal] = useState("");
  const [salvandoLocal, setSalvandoLocal] = useState(false);

  const condominioAtual = condominios.find((c) => c.id === condominioSelecionado);

  const carregarCondominios = async () => {
    setCarregando(true);
    const resposta = await fetch(`${API_URL}/api/condominios`, { headers: authHeaders() });
    const lista = await resposta.json();
    setCondominios(lista);
    if (lista.length > 0 && !condominioSelecionado) setCondominioSelecionado(lista[0].id);
    setCarregando(false);
  };

  const carregarLocais = async (condominioId: string) => {
    const resposta = await fetch(`${API_URL}/api/condominios/${condominioId}/locais`, { headers: authHeaders() });
    setLocais(await resposta.json());
  };

  const carregarEmails = async (condominioId: string) => {
    const resposta = await fetch(`${API_URL}/api/condominios/${condominioId}`, { headers: authHeaders() });
    const dados = await resposta.json();
    setEmails(dados.emailsResponsaveis ?? []);
    setTelefones(dados.telefones ?? []);
  };

  useEffect(() => {
    carregarCondominios();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (condominioSelecionado) {
      carregarLocais(condominioSelecionado);
      carregarEmails(condominioSelecionado);
    }
  }, [condominioSelecionado]);

  const alternarServico = (s: TipoServico) => {
    setServicos((atual) => (atual.includes(s) ? atual.filter((x) => x !== s) : [...atual, s]));
  };

  const criarCondominio = async () => {
    if (!nome.trim() || !cnpj.trim() || !endereco.trim()) return;
    setSalvandoCondominio(true);
    try {
      await fetch(`${API_URL}/api/condominios`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders() },
        body: JSON.stringify({
          nome,
          cnpj,
          endereco,
          servicos,
          emailsResponsaveis: emailResponsavel.trim() ? [emailResponsavel.trim()] : undefined,
        }),
      });
      setNome("");
      setCnpj("");
      setEndereco("");
      setEmailResponsavel("");
      setMostrarFormCondominio(false);
      await carregarCondominios();
    } finally {
      setSalvandoCondominio(false);
    }
  };

  const criarLocal = async () => {
    if (!nomeLocal.trim() || !condominioSelecionado) return;
    setSalvandoLocal(true);
    try {
      await fetch(`${API_URL}/api/condominios/${condominioSelecionado}/locais`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders() },
        body: JSON.stringify({ nome: nomeLocal }),
      });
      setNomeLocal("");
      setMostrarFormLocal(false);
      await carregarLocais(condominioSelecionado);
    } finally {
      setSalvandoLocal(false);
    }
  };

  const regenerarQrCode = async () => {
    if (!condominioSelecionado) return;
    await fetch(`${API_URL}/api/condominios/${condominioSelecionado}/qrcode/regenerar`, {
      method: "POST",
      headers: authHeaders(),
    });
    await carregarCondominios();
  };

  const excluirCondominio = async (id: string, nome: string) => {
    const confirmou = window.confirm(
      `Tem certeza que quer excluir o condomínio "${nome}"?\n\nO histórico de solicitações dele é mantido, mas ele deixa de aparecer no sistema e o QR Code para de funcionar.`,
    );
    if (!confirmou) return;

    await fetch(`${API_URL}/api/condominios/${id}`, { method: "DELETE", headers: authHeaders() });
    if (condominioSelecionado === id) setCondominioSelecionado(null);
    await carregarCondominios();
  };

  const excluirLocal = async (localId: string, nome: string) => {
    if (!condominioSelecionado) return;
    const confirmou = window.confirm(
      `Tem certeza que quer excluir o ambiente "${nome}"?\n\nEle deixa de aparecer no formulário do morador, mas as solicitações antigas registradas nele são mantidas.`,
    );
    if (!confirmou) return;

    await fetch(`${API_URL}/api/condominios/${condominioSelecionado}/locais/${localId}`, {
      method: "DELETE",
      headers: authHeaders(),
    });
    await carregarLocais(condominioSelecionado);
  };

  // Sobe/desce um ambiente na lista e grava a nova sequência — é essa
  // ordem que aparece no formulário do morador.
  const [erroOrdem, setErroOrdem] = useState<string | null>(null);
  const moverLocal = async (indice: number, direcao: -1 | 1) => {
    if (!condominioSelecionado) return;
    const destino = indice + direcao;
    if (destino < 0 || destino >= locais.length) return;
    const nova = [...locais];
    [nova[indice], nova[destino]] = [nova[destino], nova[indice]];
    setLocais(nova); // já mostra na tela; se falhar, recarrega do servidor
    setErroOrdem(null);
    const resposta = await fetch(`${API_URL}/api/condominios/${condominioSelecionado}/locais/ordem`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json", ...authHeaders() },
      body: JSON.stringify({ ids: nova.map((l) => l.id) }),
    }).catch(() => null);
    if (!resposta || !resposta.ok) {
      setErroOrdem("Não foi possível salvar a nova ordem. Tente de novo.");
      await carregarLocais(condominioSelecionado);
    }
  };

  const adicionarEmail = async () => {
    if (!novoEmail.trim() || !condominioSelecionado) return;
    setSalvandoEmail(true);
    try {
      await fetch(`${API_URL}/api/condominios/${condominioSelecionado}/emails`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders() },
        body: JSON.stringify({ email: novoEmail.trim() }),
      });
      setNovoEmail("");
      await carregarEmails(condominioSelecionado);
    } finally {
      setSalvandoEmail(false);
    }
  };

  const removerEmail = async (emailId: string) => {
    if (!condominioSelecionado) return;
    await fetch(`${API_URL}/api/condominios/emails/${emailId}`, { method: "DELETE", headers: authHeaders() });
    await carregarEmails(condominioSelecionado);
  };

  const adicionarTelefone = async () => {
    if (!novoTelefone.trim() || !condominioSelecionado) return;
    setSalvandoTelefone(true);
    setErroTelefone(null);
    try {
      const resposta = await fetch(`${API_URL}/api/condominios/${condominioSelecionado}/telefones`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders() },
        body: JSON.stringify({ numero: novoTelefone.trim() }),
      });
      if (!resposta.ok) {
        const dados = await resposta.json().catch(() => null);
        setErroTelefone(dados?.message ?? "Não foi possível adicionar esse telefone.");
        return;
      }
      setNovoTelefone("");
      await carregarEmails(condominioSelecionado);
    } finally {
      setSalvandoTelefone(false);
    }
  };

  const removerTelefone = async (telefoneId: string) => {
    if (!condominioSelecionado) return;
    await fetch(`${API_URL}/api/condominios/telefones/${telefoneId}`, { method: "DELETE", headers: authHeaders() });
    await carregarEmails(condominioSelecionado);
  };

  return (
    <div style={{ background: "#0a0a0a", minHeight: "100vh", display: "flex" }}>
      <NavAdmin />

      <div style={{ flex: 1, padding: "2rem 1.5rem" }}>
        <div style={{ maxWidth: 720, margin: "0 auto" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <p style={{ fontSize: 22, fontWeight: 900, color: CORES.texto, margin: 0, fontFamily: FONTES.titulo, letterSpacing: "-0.02em" }}>Cadastro de condomínios</p>
              <span style={{ fontSize: 11, fontWeight: 700, color: "#4ade80", background: "rgba(74,222,128,0.12)", border: "1px solid rgba(74,222,128,0.3)", borderRadius: 999, padding: "3px 10px" }}>
                🧹 Limpeza
              </span>
            </div>
            <p style={{ fontSize: 12, color: "#8a8a8a", margin: "4px 0 0" }}>
              QR Code, e-mails e telefones do fluxo de reclamação/limpeza do morador.
            </p>
          </div>
          <button
            onClick={() => setMostrarFormCondominio((v) => !v)}
            style={{ height: 38, padding: "0 18px", borderRadius: 9999, background: CORES.vermelho, color: "#fff", border: "none", fontSize: 12, fontWeight: 600, boxShadow: "0 8px 24px -6px rgba(255,59,59,0.45)" }}
          >
            {mostrarFormCondominio ? "Cancelar" : "+ Novo condomínio"}
          </button>
        </div>

        {mostrarFormCondominio && (
          <div style={{ background: "rgba(255,255,255,0.03)", borderRadius: 12, padding: "1.1rem", marginBottom: 20 }}>
            <input
              placeholder="Nome do condomínio"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              style={{ width: "100%", height: 38, borderRadius: 8, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", color: "#fff", padding: "0 10px", fontSize: 13, marginBottom: 8, boxSizing: "border-box" }}
            />
            <input
              placeholder="CNPJ"
              value={cnpj}
              onChange={(e) => setCnpj(e.target.value)}
              style={{ width: "100%", height: 38, borderRadius: 8, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", color: "#fff", padding: "0 10px", fontSize: 13, marginBottom: 8, boxSizing: "border-box" }}
            />
            <input
              placeholder="Endereço"
              value={endereco}
              onChange={(e) => setEndereco(e.target.value)}
              style={{ width: "100%", height: 38, borderRadius: 8, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", color: "#fff", padding: "0 10px", fontSize: 13, marginBottom: 8, boxSizing: "border-box" }}
            />
            <input
              placeholder="E-mail para receber avisos (opcional)"
              value={emailResponsavel}
              onChange={(e) => setEmailResponsavel(e.target.value)}
              style={{ width: "100%", height: 38, borderRadius: 8, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", color: "#fff", padding: "0 10px", fontSize: 13, marginBottom: 10, boxSizing: "border-box" }}
            />
            <p style={{ fontSize: 12, color: "#8a8a8a", margin: "0 0 6px" }}>Serviços contratados</p>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 14 }}>
              {(Object.keys(SERVICO_LABEL) as TipoServico[]).map((s) => (
                <button
                  key={s}
                  onClick={() => alternarServico(s)}
                  style={{
                    fontSize: 12,
                    padding: "6px 12px",
                    borderRadius: 8,
                    border: servicos.includes(s) ? "none" : "1px solid rgba(255,255,255,0.08)",
                    background: servicos.includes(s) ? "#FF3B3B" : "transparent",
                    color: servicos.includes(s) ? "#fff" : "#aaa",
                  }}
                >
                  {SERVICO_LABEL[s]}
                </button>
              ))}
            </div>
            <button
              onClick={criarCondominio}
              disabled={salvandoCondominio}
              style={{ width: "100%", height: 38, borderRadius: 9999, background: "#FF3B3B", color: "#fff", border: "none", fontSize: 13, fontWeight: 600, boxShadow: "0 8px 24px -6px rgba(255,59,59,0.45)" }}
            >
              {salvandoCondominio ? "Criando..." : "Criar condomínio"}
            </button>
          </div>
        )}

        {carregando ? (
          <p style={{ fontSize: 13, color: "#8a8a8a" }}>Carregando...</p>
        ) : condominios.length === 0 ? (
          <p style={{ fontSize: 13, color: "#8a8a8a" }}>Nenhum condomínio cadastrado ainda.</p>
        ) : (
          <>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 20 }}>
              {condominios.map((c) => (
                <div
                  key={c.id}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    borderRadius: 8,
                    border: condominioSelecionado === c.id ? "none" : "1px solid rgba(255,255,255,0.08)",
                    background: condominioSelecionado === c.id ? "#FF3B3B" : "transparent",
                    overflow: "hidden",
                  }}
                >
                  <button
                    onClick={() => setCondominioSelecionado(c.id)}
                    style={{
                      fontSize: 12,
                      padding: "7px 10px 7px 14px",
                      background: "transparent",
                      border: "none",
                      color: condominioSelecionado === c.id ? "#fff" : "#aaa",
                      cursor: "pointer",
                    }}
                  >
                    {c.nome}
                  </button>
                  <button
                    onClick={() => excluirCondominio(c.id, c.nome)}
                    title="Excluir condomínio"
                    style={{
                      fontSize: 13,
                      padding: "7px 12px 7px 4px",
                      background: "transparent",
                      border: "none",
                      color: condominioSelecionado === c.id ? "rgba(255,255,255,0.7)" : "#666",
                      cursor: "pointer",
                    }}
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>

            {/* QR Code único do condomínio */}
            <div style={{ background: "rgba(255,255,255,0.03)", borderRadius: 12, padding: "1.1rem", marginBottom: 20, display: "flex", gap: 16, alignItems: "center" }}>
              {condominioAtual?.qrCodeUrl ? (
                <img src={condominioAtual.qrCodeUrl} alt="QR Code do condomínio" style={{ width: 110, height: 110, borderRadius: 8, background: "#fff" }} />
              ) : (
                <div style={{ width: 110, height: 110, borderRadius: 8, background: "rgba(255,255,255,0.04)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, color: "#666" }}>
                  Sem QR Code
                </div>
              )}
              <div>
                <p style={{ fontSize: 13, color: "#fff", fontWeight: 500, margin: "0 0 4px" }}>QR Code do condomínio</p>
                <p style={{ fontSize: 12, color: "#8a8a8a", margin: "0 0 12px", maxWidth: 320 }}>
                  Um único QR Code para todo o condomínio — pode ser impresso e colado em vários ambientes.
                  O morador escolhe o local na hora de preencher o formulário.
                </p>
                <div style={{ display: "flex", gap: 12 }}>
                  {condominioAtual?.qrCodeUrl && (
                    <a href={condominioAtual.qrCodeUrl} download={`qrcode-${condominioAtual.nome}.png`} style={{ fontSize: 12, color: "#FF3B3B", textDecoration: "none" }}>
                      Baixar
                    </a>
                  )}
                  <button onClick={regenerarQrCode} style={{ fontSize: 12, color: "#ccc", background: "none", border: "none", cursor: "pointer", padding: 0 }}>
                    Gerar novamente
                  </button>
                </div>
              </div>
            </div>

            {/* E-mails que recebem aviso de nova solicitação */}
            <div style={{ background: "rgba(255,255,255,0.03)", borderRadius: 12, padding: "1.1rem", marginBottom: 20 }}>
              <p style={{ fontSize: 13, color: "#fff", fontWeight: 500, margin: "0 0 4px" }}>E-mails de aviso (Limpeza)</p>
              <p style={{ fontSize: 12, color: "#8a8a8a", margin: "0 0 12px" }}>
                Recebem um e-mail toda vez que um morador registra uma nova solicitação.
              </p>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: emails.length > 0 ? 12 : 0 }}>
                {emails.map((e) => (
                  <span
                    key={e.id}
                    style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, padding: "6px 6px 6px 12px", borderRadius: 8, background: "rgba(255,255,255,0.04)", color: "#ddd" }}
                  >
                    {e.email}
                    <button
                      onClick={() => removerEmail(e.id)}
                      title="Remover e-mail"
                      style={{ fontSize: 13, background: "transparent", border: "none", color: "#666", cursor: "pointer", padding: "0 2px", lineHeight: 1 }}
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <input
                  placeholder="email@exemplo.com"
                  value={novoEmail}
                  onChange={(e) => setNovoEmail(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && adicionarEmail()}
                  style={{ flex: 1, height: 36, borderRadius: 8, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", color: "#fff", padding: "0 10px", fontSize: 13 }}
                />
                <button
                  onClick={adicionarEmail}
                  disabled={salvandoEmail}
                  style={{ height: 36, padding: "0 14px", borderRadius: 8, background: "rgba(255,255,255,0.06)", color: "#fff", border: "1px solid rgba(255,255,255,0.08)", fontSize: 12, fontWeight: 600 }}
                >
                  {salvandoEmail ? "..." : "Adicionar"}
                </button>
              </div>
            </div>

            {/* Telefones que recebem aviso por WhatsApp */}
            <div style={{ background: "rgba(255,255,255,0.03)", borderRadius: 12, padding: "1.1rem", marginBottom: 20 }}>
              <p style={{ fontSize: 13, color: "#fff", fontWeight: 500, margin: "0 0 4px" }}>Telefones de aviso — WhatsApp (Limpeza)</p>
              <p style={{ fontSize: 12, color: "#8a8a8a", margin: "0 0 12px" }}>
                Recebem uma mensagem de WhatsApp toda vez que um morador registra uma nova solicitação.
              </p>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: telefones.length > 0 ? 12 : 0 }}>
                {telefones.map((t) => (
                  <span
                    key={t.id}
                    style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, padding: "6px 6px 6px 12px", borderRadius: 8, background: "rgba(255,255,255,0.04)", color: "#ddd" }}
                  >
                    {t.numero}
                    <button
                      onClick={() => removerTelefone(t.id)}
                      title="Remover telefone"
                      style={{ fontSize: 13, background: "transparent", border: "none", color: "#666", cursor: "pointer", padding: "0 2px", lineHeight: 1 }}
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <input
                  placeholder="11999999999 (DDD + número)"
                  value={novoTelefone}
                  onChange={(e) => setNovoTelefone(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && adicionarTelefone()}
                  style={{ flex: 1, height: 36, borderRadius: 8, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", color: "#fff", padding: "0 10px", fontSize: 13 }}
                />
                <button
                  onClick={adicionarTelefone}
                  disabled={salvandoTelefone}
                  style={{ height: 36, padding: "0 14px", borderRadius: 8, background: "rgba(255,255,255,0.06)", color: "#fff", border: "1px solid rgba(255,255,255,0.08)", fontSize: 12, fontWeight: 600 }}
                >
                  {salvandoTelefone ? "..." : "Adicionar"}
                </button>
              </div>
              {erroTelefone && <p style={{ fontSize: 12, color: "#ef4444", margin: "10px 0 0" }}>{erroTelefone}</p>}
            </div>

            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
              <div>
                <p style={{ fontSize: 15, fontWeight: 500, color: "#fff", margin: 0 }}>Ambientes</p>
                <p style={{ fontSize: 11, color: "#8a8a8a", margin: "2px 0 0" }}>
                  Opções que aparecem no formulário para o morador escolher
                </p>
              </div>
              <button
                onClick={() => setMostrarFormLocal((v) => !v)}
                style={{ height: 32, padding: "0 12px", borderRadius: 8, background: "transparent", border: "1px solid rgba(255,255,255,0.08)", color: "#ccc", fontSize: 12 }}
              >
                {mostrarFormLocal ? "Cancelar" : "+ Novo ambiente"}
              </button>
            </div>

            {mostrarFormLocal && (
              <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
                <input
                  placeholder="Ex: Salão de Festas"
                  value={nomeLocal}
                  onChange={(e) => setNomeLocal(e.target.value)}
                  style={{ flex: 1, height: 38, borderRadius: 8, background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)", color: "#fff", padding: "0 10px", fontSize: 13 }}
                />
                <button
                  onClick={criarLocal}
                  disabled={salvandoLocal}
                  style={{ height: 38, padding: "0 16px", borderRadius: 9999, background: "#FF3B3B", color: "#fff", border: "none", fontSize: 13, fontWeight: 600, boxShadow: "0 8px 24px -6px rgba(255,59,59,0.45)" }}
                >
                  {salvandoLocal ? "..." : "Criar"}
                </button>
              </div>
            )}

            {locais.length > 1 && (
              <p style={{ fontSize: 11, color: "#8a8a8a", margin: "0 0 8px" }}>Use ↑ e ↓ para definir a sequência em que aparecem no formulário.</p>
            )}
            {erroOrdem && <p style={{ fontSize: 12, color: "#ef4444", margin: "0 0 8px" }}>{erroOrdem}</p>}
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {locais.map((l, i) => (
                <div
                  key={l.id}
                  style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 13, padding: "6px 8px 6px 12px", borderRadius: 8, background: "rgba(255,255,255,0.03)", color: "#ddd" }}
                >
                  <span style={{ width: 20, color: "#666", fontSize: 12 }}>{i + 1}.</span>
                  <span style={{ flex: 1, minWidth: 0, overflowWrap: "anywhere" }}>{l.nome}</span>
                  <button onClick={() => moverLocal(i, -1)} disabled={i === 0} title="Subir" aria-label={`Subir ${l.nome}`} style={{ ...{ width: 28, height: 28, borderRadius: 6, background: "transparent", border: "1px solid rgba(255,255,255,0.08)", color: "#ccc", fontSize: 13, lineHeight: 1 }, opacity: i === 0 ? 0.3 : 1, cursor: i === 0 ? "default" : "pointer" }}>
                    ↑
                  </button>
                  <button onClick={() => moverLocal(i, 1)} disabled={i === locais.length - 1} title="Descer" aria-label={`Descer ${l.nome}`} style={{ ...{ width: 28, height: 28, borderRadius: 6, background: "transparent", border: "1px solid rgba(255,255,255,0.08)", color: "#ccc", fontSize: 13, lineHeight: 1 }, opacity: i === locais.length - 1 ? 0.3 : 1, cursor: i === locais.length - 1 ? "default" : "pointer" }}>
                    ↓
                  </button>
                  <button
                    onClick={() => excluirLocal(l.id, l.nome)}
                    title="Excluir ambiente"
                    style={{ fontSize: 15, background: "transparent", border: "none", color: "#666", cursor: "pointer", padding: "0 4px", lineHeight: 1 }}
                  >
                    ×
                  </button>
                </div>
              ))}
              {locais.length === 0 && <p style={{ fontSize: 12, color: "#666" }}>Nenhum ambiente cadastrado ainda.</p>}
            </div>
          </>
        )}
        </div>
      </div>
    </div>
  );
}
